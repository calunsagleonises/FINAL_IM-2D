 <?php
        include 'views/header.php';
        echo "Firstname:".$_SESSION['firstname']."<br>";
        echo "Lastname:".$_SESSION['lastname']."<br>";
        include 'views/footer.php';
?>
   
