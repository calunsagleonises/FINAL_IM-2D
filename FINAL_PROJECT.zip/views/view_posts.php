<div>
    <form class="create_post" action="models/create_post.php" method="POST">
        <textarea id="text_content" name="text_content"></textarea>
        <input type="submit" id="btn-post" name="btn-post" value="POST">
    </form>
</div>

<?php

require "./models/dbconnection.php";

$con = create_connection();

if ($con->connect_error) {
    error_log("Database Connection Failed for view_posts.php post display: " . $con->connect_error);
    echo '<div class="error_message">Could not load posts due to a database error.</div>';
} else {
    $sql_posts = "SELECT `user`.`firstname`, "
             . "`user`. `lastname`, "
             . "`post`.`text_content`, "
             . "`post`. `date`, "
             . "`post`. `time`, " // Included time as well
             . "`post`. `pid` "
             . "FROM `post` "
             . "INNER JOIN `user` "
             . "ON `user`.`uid` = `post`.uid ORDER BY pid DESC";

    $result_posts = $con->query($sql_posts);

    // Check if there are any posts
    if ($result_posts->num_rows > 0) {
        while ($row = $result_posts->fetch_assoc()) {
            echo "<div class=\"post\">"; // Wrapper div for each post
                echo "<div class=\"post-header\">"; // Container for name and date/time
                    echo "<span class=\"post-author\">" . htmlspecialchars($row['firstname'] . " " . $row['lastname']) . "</span>"; // Author name
                    echo "<span class=\"post-datetime\">" . htmlspecialchars($row['date'] . " " . $row['time']) . "</span>"; // Date and Time
                echo "</div>";
                echo "<div class=\"post-content\">" . htmlspecialchars($row['text_content']) . "</div>"; // Post content
            echo "</div>"; // Close post div
        }
    } else {
        echo "<div class='info_message'>No posts found yet. Be the first to post!</div>"; // Message if no posts
    }

    $con->close();
}
?>