<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>CAMPUS-CONNECT</title>
        <link href="./resources/style.css" rel="stylesheet" type="text/css"/>
        </head>
    <body>

        <header class="site-header">
            <div style="display: flex; align-items: center;">
            <img src="image/logo1.jpg" alt="Campus-Connect" style="height: 50px; margin-right: -20px;">
             <span style="font-size: 24px; font-weight: bold;">CAMPUS CONNECT</span>
            </div>


            <div class="navbar">
                <a href="./index.php"> HOME </a>

                <?php
                if(isset($_SESSION['uid'])){
                ?>
                    <a href="./profile.php"><?php echo htmlspecialchars($_SESSION['username']);?></a>
                    <a href="./models/logout.php">Log out</a>
                <?php
                }
                else{
                ?>
                    <a href="./login.php"> LOG IN </a>
                    <a href="./registration.php "> REGISTER </a>
                <?php
                }
                ?>
            </div>
        </header>

        </body>
</html>