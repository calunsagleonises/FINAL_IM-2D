<?php

function create_connection(){
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "campus";
    
    return new mysqli($host,$username,$password,$database);
    
}
