<?php
session_start();

require "dbconnection.php";

if (!isset($_SESSION['uid'])) {
    header("Location: ../login.php?error=not_loggedin");
    exit();
}

if (isset($_POST['text_content'])) {
    $text_content = htmlspecialchars($_POST['text_content']);

    $con = create_connection();

    if ($con->connect_error) {
        error_log("Database Connection Failed in create_post.php: " . $con->connect_error);
        header("Location: ../index.php?error=db_connect");
        exit();
    }

    $sql_post = "INSERT INTO post (text_content, date, time, uid) VALUES (?, CURDATE(), CURTIME(), ?)";
    if ($stmt = $con->prepare($sql_post)) {
        $user_id = $_SESSION['uid'];

        $stmt->bind_param("si", $text_content, $user_id);

        if ($stmt->execute()) {
            $stmt->close();
            $con->close();
            header("Location: ../index.php?post_success=1");
            exit();
        } else {
            error_log("Error executing post insert statement: " . $stmt->error);
            $stmt->close();
            $con->close();
            header("Location: ../index.php?error=post_failed");
            exit();
        }

    } else {
        error_log("Error preparing post statement: " . $con->error);
        $con->close();
        header("Location: ../index.php?error=stmt_prepare");
        exit();
    }

} else {
    error_log("Post content not received in create_post.php");
    header("Location: ../index.php?error=no_content");
    exit();
}
?>