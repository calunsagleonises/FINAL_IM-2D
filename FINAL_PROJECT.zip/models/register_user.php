-<?php
session_start();

require "dbconnection.php";

$un = htmlspecialchars($_POST['uname']);
$em = htmlspecialchars($_POST['email']);
$fn = htmlspecialchars($_POST['fname']);
$ln = htmlspecialchars($_POST['lname']);
$gndr = htmlspecialchars($_POST['gender']);
$bdate = htmlspecialchars($_POST['bdate']);
$pass = htmlspecialchars($_POST['pass']);
$conpass = htmlspecialchars($_POST['conpass']);

$con = create_connection();

if ($con->connect_error) {
    error_log("Database Connection Failed in register_user.php: " . $con->connect_error);
    header("location: ../registration.php?error=db_connect");
    exit();
}

$uname_error = 0;
$email_error = 0;
$errors = [];

$sql_uname = "SELECT uid FROM user WHERE username = ?";
if ($stmt_uname = $con->prepare($sql_uname)) {
    $stmt_uname->bind_param("s", $un);
    $stmt_uname->execute();
    $stmt_uname->store_result();

    if ($stmt_uname->num_rows > 0) {
        $uname_error = 1;
        $errors[] = 'uname_error=1';
    }
    $stmt_uname->close();
} else {
    error_log("Error preparing username check statement: " . $con->error);
    $errors[] = 'error=stmt_prepare_uname';
}

$sql_email = "SELECT uid FROM user WHERE email = ?";
    if ($stmt_email = $con->prepare($sql_email)) {
    $stmt_email->bind_param("s", $em);
    $stmt_email->execute();
    $stmt_email->store_result();

    if ($stmt_email->num_rows > 0) {
        $email_error = 1;
        $errors[] = 'email_error=1';
    }
    $stmt_email->close();
} else {
    error_log("Error preparing email check statement: " . $con->error);
     $errors[] = 'error=stmt_prepare_email';
}

$pass_match = strcmp($pass, $conpass);
if ($pass_match !== 0) {
     $errors[] = 'pass_error=1';
}

if (empty($errors)) {
    $sql_insert = "INSERT INTO user (username, email, firstname, lastname, gender, birthdate, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
    if ($stmt_insert = $con->prepare($sql_insert)) {
        $stmt_insert->bind_param("sssssss", $un, $em, $fn, $ln, $gndr, $bdate, $pass);

        if ($stmt_insert->execute()) {
            $stmt_insert->close();
            $con->close();
            header("Location: ../login.php?regsuccess=1");
            exit();
        } else {
            error_log("Error executing user insert statement: " . $stmt_insert->error);
            $errors[] = 'error=insert_failed';
        }
    } else {
        error_log("Error preparing user insert statement: " . $con->error);
         $errors[] = 'error=stmt_prepare_insert';
    }
}

$con->close();
if (!empty($errors)) {
    $redirect_url = "../registration.php?" . implode('&', $errors);
    header("Location: " . $redirect_url);
    exit();
} else {
     header("Location: ../registration.php?error=unknown");
     exit();
}
?>