<?php
session_start();

require "dbconnection.php";

$un_or_email = htmlspecialchars($_POST['uname']);
$pass = htmlspecialchars($_POST['pass']);
// Assuming 'signedin' is handled later if needed, it's not used in the core login logic here.

$con = create_connection();

if ($con->connect_error) {
    error_log("Database Connection Failed in login_user.php: " . $con->connect_error);
    header("Location: ../login.php?error=db_connect");
    exit();
}

// Use prepared statement to check for user by username OR email
$sql_login = "SELECT uid, username, firstname, lastname, password FROM user WHERE username = ? OR email = ?";
if ($stmt_login = $con->prepare($sql_login)) {
    $stmt_login->bind_param("ss", $un_or_email, $un_or_email);
    $stmt_login->execute();
    $result_login = $stmt_login->get_result(); // Get the result set

    if ($result_login->num_rows === 1) {
        $row = $result_login->fetch_assoc();
        $stored_password = $row['password']; // Get the stored plain text password

        // --- Plain Text Password Comparison (as requested) ---
        // WARNING: This is insecure. Passwords should be hashed and verified with password_verify().
        if ($pass === $stored_password) {
        // --- End Plain Text Password Comparison ---

            $_SESSION['uid'] = $row['uid'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['firstname'] = $row['firstname'];
            $_SESSION['lastname'] = $row['lastname'];

            $stmt_login->close();
            $con->close();
            header("Location: ../index.php");
            exit();
        } else {
            // Password does not match
            $stmt_login->close();
            $con->close();
            header("Location: ../login.php?error=invalid_credentials");
            exit();
        }
    } else {
        // No user found with that username or email
        $stmt_login->close();
        $con->close();
        header("Location: ../login.php?error=invalid_credentials");
        exit();
    }

} else {
    error_log("Error preparing login statement: " . $con->error);
    $con->close();
    header("Location: ../login.php?error=stmt_prepare");
    exit();
}

?>